var Message = function Message() {
	var x,y,w,h,s,message, type,tick = 0,duration, delay;
}
var Point = function Point() {
	var x,y;
}
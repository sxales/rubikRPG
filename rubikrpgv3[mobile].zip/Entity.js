var Entity = function Entity() {
	var type = -1;
	var statuseffect = 0;
	var hp = 0, currenthp = 0; //progress bars
	var xp = 0, currentxp = 0; //progress bars
	var atk = 0, def = 0, spd = 0, rcv = 0; //atributes
	var spl = 0, act = 0, sts = 0;; //counters
}